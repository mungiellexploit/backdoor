pertama jalanin ftpgrabber
kedua jalanin ftphunter
ketiga jalanin ftpsplit
keempat jalanin scan

kalau udah selesai scan nya
lu cari yang port selain 21 pokoknya, itu ssh
ada di log.txt