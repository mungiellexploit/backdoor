import os
import ftplib
import paramiko
from multiprocessing import Pool
from colorama import Fore, Style

bl = Fore.BLUE
wh = Fore.WHITE
gr = Fore.GREEN
red = Fore.RED
res = Style.RESET_ALL
yl = Fore.YELLOW

def check_ftp_connection(domain, host, port, username, password):
    try:
        ftp = ftplib.FTP()
        ftp.connect(host, port, timeout=3)
        ftp.login(username, password)
        ftp.quit()
        return True
    except Exception as e:
        return False

def check_sftp_connection(domain, host, port, username, password):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(host, port, username, password, timeout=3)
        ssh.close()
        return True
    except Exception as e:
        return False

def check_connection(line, line_number):
    fields = line.strip().split("|")
    if len(fields) == 5:
        domain, host, port, username, password = fields
        port = int(port)

        if port == 21:
            result = check_ftp_connection(domain, host, port, username, password)
        else:
            result = check_sftp_connection(domain, host, port, username, password)

        if result:
            with open("log.txt", "a") as f:
                f.write("domain: {}\n".format(domain))
                f.write("host: {}\n".format(host))
                f.write("port: {}\n".format(port))
                f.write("username: {}\n".format(username))
                f.write("password: {}\n".format(password))
                f.write("\n")
            print(gr + "Success (line {}): {}".format(line_number, line.strip()) + res)
        else:
            print(red + "Failed (line {}): {}".format(line_number, line.strip()) + res)
    else:
        print("Invalid line format (line {}): {}".format(line_number, line))

os.system('cls' if os.name == 'nt' else 'clear')

if __name__ == '__main__':
    filename = input("Masukkan nama file : ")

    if not os.path.exists(filename):
        print("File {} tidak ditemukan.".format(filename))
        exit()

    with open(filename, "r", encoding="utf-8") as f:
        lines = f.readlines()

    pool = Pool()
    pool.starmap(check_connection, [(line, i+1) for i, line in enumerate(lines)])
    pool.close()
    pool.join()
