import requests
import re
import time
from colorama import Fore, Style
from tqdm import tqdm

with open("sftpfound.txt", "r") as f:
    lines = f.readlines()

counter = 0
total = len(lines)

with open("ready.txt", "w") as f:
    f.write("Result:\n")

processed_hosts = set()

for line in tqdm(lines, desc='Processing connections', colour='green', leave=False):
    counter += 1

    url = line.strip()

    num_retries = 0

    while True:
        try:
            response = requests.get(url)
            text = response.text

            host_pattern = r'"host"\s*:\s*"([^"]*)"'
            host_pattern_alt = r'"host":\s+"([^"]+)"'
            username_pattern = r'"username"\s*:\s*"([^"]*)"'
            username_pattern_alt = r'"user":\s+"([^"]+)"'
            password_pattern = r'"password"\s*:\s*"([^"]*)"'
            password_pattern_alt = r'"password":\s+"([^"]+)"'
            port_pattern = r'"port"\s*:\s*(\d+)'
            port_pattern2 = r'"port":\s+"([^"]+)"'

            host_match = re.search(host_pattern, text) or re.search(host_pattern_alt, text)
            username_match = re.search(username_pattern, text) or re.search(username_pattern_alt, text)
            password_match = re.search(password_pattern, text) or re.search(password_pattern_alt, text)
            port_match = re.search(port_pattern, text)
            if not port_match:
                port_match = re.search(port_pattern2, text)
                if not port_match:
                    port = 21
                else:
                    port = port_match.group(1)
            else:
                port = port_match.group(1)

            if host_match and username_match and password_match:
                host = host_match.group(1)
                username = username_match.group(1)
                password = password_match.group(1)

                if host in processed_hosts:
                    print(Fore.YELLOW + "Host {} pre-processed. Skip".format(host) + Style.RESET_ALL)
                    break

                with open("ready.txt", "a") as f:
                    f.write("{}|{}|{}|{}|{}\n".format(url, host, port, username, password))
                    processed_hosts.add(host)

                print(Fore.GREEN + "Connection {} from {} successfully processed".format(counter, total) + Style.RESET_ALL)
                break

            else:
                print(Fore.YELLOW + "Data not found. Proceed to the next URL" + Style.RESET_ALL)
                break

        except requests.exceptions.RequestException:
            num_retries += 1
            print(Fore.RED + "Connection {} from {} failed. Try again in 5 seconds...".format(counter, total) + Style.RESET_ALL)
            time.sleep(5)
            if num_retries == 3:
                print(Fore.RED + "Connection {} from {} failed after 3 attempts. Skip this connection".format(counter, total) + Style.RESET_ALL)
                break

print(Fore.GREEN + "Processing complete. Results are stored in ready.txt" + Style.RESET_ALL)
