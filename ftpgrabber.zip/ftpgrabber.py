import requests
import json
import time
import os
from colorama import init, Fore, Style

init()

os.system('cls' if os.name == 'nt' else 'clear')

banner = r'''
███████╗████████╗██████╗      ██████╗ ██████╗  █████╗ ██████╗ ██████╗ ███████╗██████╗ 
██╔════╝╚══██╔══╝██╔══██╗    ██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔══██╗
█████╗     ██║   ██████╔╝    ██║  ███╗██████╔╝███████║██████╔╝██████╔╝█████╗  ██████╔╝
██╔══╝     ██║   ██╔═══╝     ██║   ██║██╔══██╗██╔══██║██╔══██╗██╔══██╗██╔══╝  ██╔══██╗
██║        ██║   ██║         ╚██████╔╝██║  ██║██║  ██║██████╔╝██████╔╝███████╗██║  ██║
╚═╝        ╚═╝   ╚═╝          ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝
                                                                                      

Coded by Vexelvox
'''

print(Fore.GREEN + banner)
print(Style.RESET_ALL)

headers = {
    'api-key': 'Mmq79BX7Brz4yxUW3VX6hJL8S_rznVLdeNNvBYh4CzNsx5he',
    'Accept': 'application/json'
}

params = {
    'page': '0',
    'q': '+plugin:"VsCodeSFTPPlugin"',
    'scope': 'leak'
}

host = input("Press enter to continue... ")
if host:
    params['q'] += f' +host:"{host}"'

max_page = int(input("Enter Page Number Max: "))

with open('list.txt', 'a') as file:
    all_results = set()
    for page in range(max_page + 1):
        params['page'] = str(page)
        response = requests.get('https://leakix.net/search', headers=headers, params=params)

        if response.status_code == 200:
            data = json.loads(response.content)
            results = []
            for item in data:
                if 'host' in item:
                    results.append(item['host'])
            all_results.update(results)
            print(Fore.BLUE + f'Page {page} Results : ', end='')
            for i in range(10):
                time.sleep(0.1)
                print(Fore.BLUE + '.', end='', flush=True)
            print(Fore.BLUE + f' ({len(results)} results)')
            print(Style.RESET_ALL)
        elif response.status_code == 204:
            print(Fore.BLUE + f'No more results on page {page}')
            print(Style.RESET_ALL)
            break
        else:
            print(f'Request failed with status code {response.status_code}')

    # write the unique results to the file
    for result in all_results:
        file.write(result + '\n')

print(Fore.GREEN + f'Total unique results found: {len(all_results)}')
print(Style.RESET_ALL)
